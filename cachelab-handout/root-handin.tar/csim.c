//22307110315 ZouTongjin
#include "cachelab.h"
#include<unistd.h>
#include<getopt.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<limits.h>
#include<stddef.h>
int miss_cnt=0,eviction_cnt=0,hit_cnt=0;
char t[1000];
int v=0;
typedef struct cache_line{
	int valid;
	int tag;
	int time;//most uncommon used
}Cache_line;
typedef struct cache_{
	int B;
	int E;
	int S;
	Cache_line **line;
}Cache;
Cache *cache=NULL;
void Init_cache(int s,int E,int b){
	int S=1<<s;
	int B=1<<b;
	cache=(Cache*)malloc(sizeof(Cache));
	cache->S=S;
	cache->E=E;
	cache->B=B;
	cache->line=(Cache_line**)malloc(sizeof(Cache_line*)*S);
	for(int i=0;i<S;++i){
		cache->line[i]=(Cache_line*)malloc(sizeof(Cache_line)*E);
		for(int j=0;j<E;++j){
			cache->line[i][j].valid=0;
			cache->line[i][j].tag=-1;
			cache->line[i][j].time=0;
		}
	}
}
void update_time_tag(int op_e,int op_s,int op_tag){
	cache->line[op_s][op_e].valid=1;
	cache->line[op_s][op_e].tag=op_tag;
	for(int i=0;i<cache->E;++i){
		if(cache->line[op_s][i].valid==1)
			cache->line[op_s][i].time++;
	}
	cache->line[op_s][op_e].time=0;
}
int change_by_time(int op_s){
	int max_e=0,max_time=0;
	for(int i=0;i<cache->E;++i){
		if(cache->line[op_s][i].time>max_time){
			max_time=cache->line[op_s][i].time;
			max_e=i;
		}
	}
	return max_e;
}
int get_index(int op_tag,int op_s)
{
	for(int i=0;i<cache->E;++i){
		if(cache->line[op_s][i].valid&&cache->line[op_s][i].tag==op_tag)
			return i;
	}
	return -1;
}
int is_full(int op_s)
{	
	for(int i=0;i<cache->E;++i){
		if(cache->line[op_s][i].valid==0)
			return i;
	}
	return -1;
}
void update_cache(int op_s,int op_tag){
	int index=get_index(op_tag,op_s);
	if(index==-1){
		miss_cnt++;
		if(v==1)
			printf("miss ");
		int i=is_full(op_s);
		if(i==-1){
			eviction_cnt++;
			if(v==1)
				printf("eviction");
			i=change_by_time(op_s);
		}
		update_time_tag(i,op_s,op_tag);
	}
	else{
		hit_cnt++;
		if(v==1)
			printf("hit");
		update_time_tag(index,op_s,op_tag);
	}
}
void get_arguments(int s,int E,int b){
	FILE *file;
	file=fopen(t,"r");
	if(file==NULL)
		exit(-1);
	char instruct;
	unsigned address;
	int size;
	while(fscanf(file,"%c %x %d",&instruct,&address,&size)>0){
		int op_tag=address>>(s+b);
		int op_s=(address>>b)&(((unsigned)(-1))>>(8*sizeof(unsigned)-s));
		switch(instruct){
			case 'M':
				update_cache(op_s,op_tag);
				update_cache(op_s,op_tag);
				break;
			case 'L':
				update_cache(op_s,op_tag);
				break;
			case 'S':
				update_cache(op_s,op_tag);
				break;
		}
	}
	fclose(file);
}
void print_help(){
	printf("Usage: ./csim-ref [-hv] -s <num> -E <num> -b <num> -t <file>\n");
	printf("Options:\n");
  	printf("-h         Print this help message.\n");
  	printf("-v         Optional verbose flag.\n");
  	printf("-s <num>   Number of set index bits.\n");
  	printf("-E <num>   Number of lines per set.\n");
  	printf("-b <num>   Number of block offset bits.\n");
  	printf("-t <file>  Trace file.\n");
	printf("Examples:\n");
  	printf("linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n");
  	printf("linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
}
void free_Cache(){
	int s=cache->S;
	for(int i=0;i<s;++i)
		free(cache->line[i]);
	free(cache->line);
	free(cache);
}
int main(int argc,char *argv[])
{
    char opt;
    int s,E,b;
    while(-1!=(opt=getopt(argc,argv,"hvs:E:b:t:"))){
    	switch(opt){
    		case 'h':
    			print_help();
    			exit(0);
    		case 'v':
    			v=1;
    			break;
    		case 's':
    			s=atoi(optarg);
    			break;
    		case 'E':
    			E=atoi(optarg);
    			break;
    		case 'b':
    			b=atoi(optarg);
    			break;
    		case 't':
    			strcpy(t,optarg);
    			break;
    		default:
    			print_help();
    			exit(-1);
    	}
    }
    Init_cache(s,E,b);
    get_arguments(s,E,b);
    free_Cache();
    printSummary(hit_cnt, miss_cnt,eviction_cnt);
    return 0;
}
